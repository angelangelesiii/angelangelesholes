// JS for animating css after scrolling on a specified amount
function init() {
	// Adds a scroll event listener
    window.addEventListener('scroll', function(e){
    	// Variable declaration:
    	// Distance Y is for determining the Y axis offset of the page
    	// shrinkOn is the value to be met before to set the following if statement true
    	// box is the variable that holds the css selector to be used for animating
        var distanceY = window.pageYOffset || document.documentElement.scrollTop,
            shrinkOn = 80,
            box = document.querySelector("header");
        // if "distance scrolled" is greater than "shrinkOn (change to set limit)"
        // animate into ".box.smaller" css rule (see style.css)
        if (distanceY > shrinkOn) {
            classie.add(box,"smaller");
        // if ".box.smaller" css rule  is true while offsetY is less than shrinkOn
        // remove .box.smaller to animate into original state
        } else {
            if (classie.has(box,"smaller")) {
                classie.remove(box,"smaller");
            }
        }
        // change animation properties like speed and selector property in the css file
    });
}
window.onload = init();

// tutorial at http://callmenick.com/2014/02/18/create-an-animated-resizing-header-on-scroll/
