<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Angel Angeles">
	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
	<link rel="icon" href="/favicon.ico" type="image/x-icon">
	<title>Angel Angeles III</title>
	<!-- STYLESHEET -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- /STYLESHEET -->
	<!-- JAVASCRIPT -->
	<script src="js/classie.js"></script>
	<script src="js/animate.js"></script>
	<!-- /JAVASCRIPT -->
</head>

<body>

	<header class="site-header">
		<div class="wrapper">

			<a href="index.php"><img src="img/logo.png" alt="Angel Angeles" class="logo"></a>

			<nav class="site-nav">
				<ul class="clearfix">
					<li><a href="#">HOME</a></li>
					<li><a href="#">PORTFOLIO</a></li>
					<li><a href="#">BLOG</a></li>
					<li><a href="#">CONTACT ME</a></li>
				</ul>
			</nav>

		</div>
	</header>
	
	<!-- MAIN CONTENT -->
	<div class="main-content">


<!-- BODY CONTENTS -->