<!-- FOOTER -->

	
	</div>
	<!-- /MAIN CONTENT -->
	
	<footer class="site-footer">
		<div class="wrapper">
		<p class="footer-info">&copy;2015 Angel Angeles. All rights reserved.</p>
		</div>
	</footer>

</body>

</html>