<?php include('header.php') ?>
<!-- BODY -->
	
	<div class="wrapper clearfix">
		<div class="content-container">

			<article class="post">
				<h2>Hello World!</h2>
				<footer class="article-subtitle">Post by Angel Angeles on March 27, 2015</footer>
				<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit. Omnis deleniti eius eum, iusto accusamus magnam nam dolores tempora ipsum minus nihil! Soluta est, culpa tempora repellat ratione dolores debitis minima?</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
			</article>

			<article class="post">
				<h2>Some Kind of an Ice Cream </h2>
				<footer class="article-subtitle">Post by Angel Angeles on March 14, 2015</footer>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis deleniti eius eum, iusto accusamus magnam nam dolores tempora ipsum minus nihil! Soluta est, culpa tempora repellat ratione dolores debitis minima?</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet fugiat similique sint, aliquam, neque totam quo libero, eveniet, quaerat corporis eligendi ab. Odio quaerat corporis aut magnam eligendi, ab eveniet!</p>
			</article>

		</div>

		<aside class="sidebar">
			<article>
				<h3>This is a Sidebar</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero porro aliquam minima earum perspiciatis corporis autem laborum sint illo magni ducimus tenetur repellat rem architecto quae, nobis officiis commodi nemo.</p>
			</article>
			<article>
				<h3>This is another Item in the Sidebar</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero porro aliquam minima earum perspiciatis corporis autem laborum sint illo magni ducimus tenetur repellat rem architecto quae, nobis officiis commodi nemo.</p>
			</article>
		</aside>



	</div>
	
<!-- /BODY -->
<?php include('footer.php') ?>
